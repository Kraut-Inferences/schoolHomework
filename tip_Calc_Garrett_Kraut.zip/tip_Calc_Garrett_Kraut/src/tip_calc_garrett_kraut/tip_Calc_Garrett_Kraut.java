
package tip_calc_garrett_kraut;

import java.util.*;
public class tip_Calc_Garrett_Kraut {

    public static void main(String[] args) {
        Scanner input;
        input = new Scanner(System.in);
        System.out.print("Enter restaurant bill Total then gratuity =>");
        double restaurant_Bill = input.nextDouble();
        double gratuity_Percent = input.nextDouble()/100;
        double gratuity = restaurant_Bill * gratuity_Percent;
        double total_Bill = restaurant_Bill + gratuity;
        System.out.println("gratuity:\t $" + gratuity);
        System.out.println("total bill:\t$" + total_Bill);
    }
    
}
