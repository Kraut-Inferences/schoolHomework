

package arraysgarrettkraut;
import javax.swing.*;

public class ArraysGarrettKraut {

    static int numberOfInputs;
    public static void main(String[] args) {
        numberOfInputs = Integer.parseInt(JOptionPane.showInputDialog("Enter number of inputs to display"));
        int[] Array = new int[numberOfInputs];
        int i = 0;
        while(i < numberOfInputs){
            Array[i] = Integer.parseInt(JOptionPane.showInputDialog("Enter number for position" + (i + 1)));
            i = i + 1;
        }
        while(i > 0){
            i = i - 1;
            JOptionPane.showMessageDialog(null, Array[i]);
        }
    }
    
}
