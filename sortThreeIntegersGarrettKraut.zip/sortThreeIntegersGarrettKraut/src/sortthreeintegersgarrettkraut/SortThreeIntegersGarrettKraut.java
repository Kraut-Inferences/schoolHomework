
package sortthreeintegersgarrettkraut;

import java.util.Scanner;

public class SortThreeIntegersGarrettKraut {

    public static void main(String[] args) {
        System.out.print("Enter 3 numbers=> ");
        Scanner input = new Scanner(System.in);
        int first_num = input.nextInt();
        int sec_num = input.nextInt();
        int third_num = input.nextInt();
        int num1 = 0;
        int num2 = 0;
        int num3 = 0;
        
        //find num1
        if(first_num <= sec_num){
            if(sec_num <= third_num){
                num1 = first_num;
            }
        }
        else;
        if(sec_num <= first_num){
            if(first_num <= third_num){
                num1 = sec_num;
            }
        }
        if(third_num <= first_num){
            if(first_num <= sec_num){
                num1 = third_num;
            }
        }
        
        if(third_num <= sec_num){
            if(sec_num <= first_num){
                num1 = third_num;
            }
        }
        //find num3
        if(first_num <= sec_num){
            if(sec_num <= third_num){
                num3 = third_num;
            }
        }
        else;
        if(sec_num <= first_num){
            if(first_num <= third_num){
                num3 = third_num;
            }
        }
        if(third_num <= first_num){
            if(first_num <= sec_num){
                num3 = sec_num;
            }
        }
        
        if(third_num <= sec_num){
            if(sec_num <= first_num){
                num3 = first_num;
            }
        }
        
        //find num2
        if(num1 < first_num){
            if(first_num < num3){
                num2 = first_num;
            }
        }
        if(num1 < sec_num){
            if(sec_num < num3){
                num2 = sec_num;
            }
        }
        if(num1 < third_num){
            if(third_num < num3){
                num2 = third_num;
            }
        }
        System.out.print(num1 + " " + num2 + " " + num3);
        }
    }
