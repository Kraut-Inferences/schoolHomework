

package computingtaxes;

import java.util.Scanner;
public class ComputingTaxes {

    public static void main(String[] args) {
        // creat a scanner
        Scanner input = new Scanner(System.in);
        
        // prompt the user to enter filing status
        System.out.print("(0-single filer, 1-married jointly or qualifying wido(er),"
        + "\n2-married separately, 3-head of household)\n" + "enter the filing status: ");
        int status = input.nextInt();
        
        // prompt the user to enter taxable income
        System.out.print("Enter the taxable income: ");
        double income = input.nextDouble();
        
        // compute tax
        double tax = 0;
        
        if(status == 0){ // compute tax for single filers
            if(income <= 8350)
                tax = income * 0.10;
            else if (income <= 33950)
                tax = 8350 * 0.10 + (income - 8350) * 0.15;
            else if (income <= 82250)
                tax = 8350 * 0.10 + (33950 - 8350) * 0.15 + (income - 33950) * 0.25;
            else if (income <= 171550)
                tax = 8350 * 0.10 + (33950 - 8350) * 0.15 + (82250 -33950) * 0.25 + (income - 82250) * 0.28;
            else if (income <= 372950)
                tax = 8350 * 0.10 + (33950 - 8350) * 0.15 + (82250 - 33950) * 0.25 + (171550 - 82250) * 0.28 + (372950 - 171550) * 0.33;
            else
                tax = 8350 * 0.10 + (33950 - 8350) * 0.15 + (82250 - 33950) * 0.25 + (171550 - 82250) * 0.28 + (372950 - 171550) * 0.33 + (income - 372950) * 0.35;
        }
        else if (status == 1){// left as exercise
            //Compute tax for married file jointly or qualifying widow(er)
        }
        else if (status == 2){// compute tax for married separately
            // left as exercise
        }
        else if (status == 3){// compute tax for head of household
            // left as exercise
        }
        else {
            System.out.println("Error: invalid status");
            System.exit(1);
        }
        
        //Display the result
        System.out.println("Tax is " + (int)(tax * 100)/100.0);
    }
    // 0 && 8349, 0 && 30000, 0 && 80000, 0 && 150000, 0 && 300000, 0 && 1000000
    // 1, 2, 3, 4, n
}
