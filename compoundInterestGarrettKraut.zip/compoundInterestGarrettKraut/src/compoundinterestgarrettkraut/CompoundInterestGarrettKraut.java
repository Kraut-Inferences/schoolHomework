/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package compoundinterestgarrettkraut;

import java.util.Scanner;


public class CompoundInterestGarrettKraut {
    public static void main(String[] args) {
        System.out.print("enter monthly saving gains then annual percent=>");
        Scanner input;
        input = new Scanner(System.in);
        double monthlySavings = input.nextDouble();
        double interestPercent = (input.nextDouble()/100)/12 + 1;
        double collectiveValue = 0;
        int i = 0;
        while(i != 6){
            collectiveValue += monthlySavings;
            collectiveValue *= interestPercent;
            i = i + 1;
        }
        System.out.print("total collective value after 6 months => " + collectiveValue);
        
    }
}
